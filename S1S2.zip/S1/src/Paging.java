public interface Paging {
    int pagesCounting();
}
