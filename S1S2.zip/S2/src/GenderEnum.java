public enum GenderEnum {
    M, F, X;
}