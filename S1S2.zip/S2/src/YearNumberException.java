class YearNumberException extends Exception {
    public YearNumberException(String message) {
        super(message);
    }

}
